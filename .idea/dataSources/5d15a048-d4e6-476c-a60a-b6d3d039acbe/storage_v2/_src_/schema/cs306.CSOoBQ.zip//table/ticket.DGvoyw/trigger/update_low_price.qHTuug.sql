create definer = root@localhost trigger update_low_price
    before update
    on ticket
    for each row
BEGIN
	IF OLD.Price <> NEW.Price AND OLD.Price < 49.99 THEN
		SET NEW.Price = 49.99;
            	
	END IF;
END;

